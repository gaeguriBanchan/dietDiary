import React from "react";
import Title from "../base/title";

const Header = () => {
  return <div></div>;
};

export default Header;
