// import React from 'react'
// import { LoginProvider } from '../context/LoginContext'
// import Login from './Login'

// const RealLogin = () => {
//   return (
//     <LoginProvider>
//       <Login/>
//     </LoginProvider>
//   )
// }

// export default RealLogin